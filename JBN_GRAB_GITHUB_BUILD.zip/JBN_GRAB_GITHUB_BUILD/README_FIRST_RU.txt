JBN GRAB — ОБЛАЧНАЯ СБОРКА ЧЕРЕЗ GITHUB ACTIONS

1. Открой https://github.com и войди в аккаунт.
2. Нажми New repository (или + -> New repository).
3. Название: jbn-grab-build
4. Выбери Public или Private, поставь галочку Add a README можно не ставить.
5. Создай репозиторий.
6. Загрузить файлы: Add file -> Upload files.
7. Распакуй этот архив на компьютере и перетащи ВСЁ СОДЕРЖИМОЕ папки
   JBN_GRAB_GITHUB_BUILD в окно Upload files. Важно: вместе с обычными
   файлами должна загрузиться скрытая папка .github/workflows/build.yml.
8. Нажми Commit changes.
9. Открой вкладку Actions -> Build JBN Grab (Linux i386) -> Run workflow -> Run workflow.
10. Дождись завершения. Если зелёная галочка — открой запуск, внизу Artifacts,
    скачай JBN-GRAB-LINUX-I386.zip и прикрепи его сюда для проверки.

ВАЖНО:
- Ничего не загружай на игровой сервер до моей проверки.
- Если Actions покажет красный крест, скачай/скопируй лог ошибки и пришли сюда.
- Сборка не пересобирает сам Metamod-R. Она собирает отдельный модуль
  jbn_bsp_native.so для загрузки Metamod.
- Workflow проверяет ELF-архитектуру нативного модуля как часть сборки.
